import json
from pathlib import Path
from dotenv import load_dotenv
import os

load_dotenv()
# test bot
BOT_TOKEN = "7483133913:AAHYVyw9KFxFnrISqx88i_k2N5FhALsFflU"

ADMINS = [5119362846, 5100403147, 5141702856]
